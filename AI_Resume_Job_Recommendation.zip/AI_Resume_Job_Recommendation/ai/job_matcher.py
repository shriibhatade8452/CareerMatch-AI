from ai.skill_extractor import extract_skills


# =========================================================
# NORMALIZE SKILL NAME
# =========================================================

def normalize_skill(skill):

    skill = skill.strip().lower()

    aliases = {
        "natural language processing": "nlp",
        "machine learning": "machine learning",
        "deep learning": "deep learning",
        "artificial intelligence": "artificial intelligence",
        "scikit learn": "scikit-learn",
        "scikit-learn": "scikit-learn",
        "nodejs": "node.js",
        "node js": "node.js",
        "mysql": "mysql",
        "sql": "sql"
    }

    return aliases.get(skill, skill)


# =========================================================
# CLEAN SKILL LIST
# =========================================================

def clean_skills(skills):

    cleaned = []

    for skill in skills:

        normalized = normalize_skill(skill)

        if normalized and normalized not in cleaned:

            cleaned.append(normalized)

    return cleaned


# =========================================================
# CALCULATE JOB MATCH
# =========================================================

def calculate_job_match(resume_text, required_skills):

    # -----------------------------------------------------
    # Extract resume skills
    # -----------------------------------------------------

    resume_skills = extract_skills(
        resume_text or ""
    )

    resume_skills = clean_skills(
        resume_skills
    )

    # -----------------------------------------------------
    # Convert required skills into a list
    # -----------------------------------------------------

    if isinstance(required_skills, str):

        job_skills = [
            skill.strip()
            for skill in required_skills.split(",")
            if skill.strip()
        ]

    elif required_skills:

        job_skills = list(required_skills)

    else:

        job_skills = []

    job_skills = clean_skills(
        job_skills
    )

    # -----------------------------------------------------
    # Find matched skills
    # -----------------------------------------------------

    matched_skills = []

    for skill in job_skills:

        if skill in resume_skills:

            matched_skills.append(skill)

    # -----------------------------------------------------
    # Find missing skills
    # -----------------------------------------------------

    missing_skills = []

    for skill in job_skills:

        if skill not in resume_skills:

            missing_skills.append(skill)

    # -----------------------------------------------------
    # Calculate match percentage
    # -----------------------------------------------------

    if job_skills:

        match_score = (
            len(matched_skills)
            / len(job_skills)
        ) * 100

    else:

        match_score = 0

    # -----------------------------------------------------
    # Return result
    # -----------------------------------------------------

    return {
        "resume_skills": resume_skills,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "match_score": round(match_score, 2)
    }