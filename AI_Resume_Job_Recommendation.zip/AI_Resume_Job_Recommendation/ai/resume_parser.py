import os
import re
from PyPDF2 import PdfReader
from docx import Document


def clean_extracted_text(text):
    """
    Cleans and formats extracted resume text for better display.
    """

    if not text:
        return ""

    # Normalize line endings
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # Remove excessive spaces
    text = re.sub(r"[ \t]+", " ", text)

    # Add line breaks before common resume headings
    headings = [
        "OBJECTIVE",
        "SUMMARY",
        "PROFILE",
        "EDUCATION",
        "SKILLS",
        "TECHNICAL SKILLS",
        "EXPERIENCE",
        "WORK EXPERIENCE",
        "PROJECTS",
        "PROJECT",
        "CERTIFICATIONS",
        "CERTIFICATION",
        "ACHIEVEMENTS",
        "INTERNSHIP",
        "INTERNSHIPS",
        "CONTACT",
        "LANGUAGES",
        "INTERESTS",
        "HOBBIES",
        "PERSONAL DETAILS"
    ]

    for heading in headings:
        pattern = r"\s+" + re.escape(heading) + r"\s+"
        text = re.sub(
            pattern,
            f"\n\n{heading}\n",
            text,
            flags=re.IGNORECASE
        )

    # Clean excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


def extract_text_from_pdf(file_path):
    text = ""

    reader = PdfReader(file_path)

    for page in reader.pages:
        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return clean_extracted_text(text)


def extract_text_from_docx(file_path):
    text = ""

    document = Document(file_path)

    for paragraph in document.paragraphs:
        paragraph_text = paragraph.text.strip()

        if paragraph_text:
            text += paragraph_text + "\n"

    return clean_extracted_text(text)


def extract_resume_text(file_path):
    extension = os.path.splitext(file_path)[1].lower()

    if extension == ".pdf":
        return extract_text_from_pdf(file_path)

    elif extension == ".docx":
        return extract_text_from_docx(file_path)

    else:
        raise ValueError(
            "Unsupported file format. Please upload PDF or DOCX."
        )