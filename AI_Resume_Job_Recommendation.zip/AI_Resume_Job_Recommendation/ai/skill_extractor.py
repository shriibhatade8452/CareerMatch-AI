import re


# Skills that our system can currently recognize
SKILLS = [
    "python",
    "java",
    "javascript",
    "c",
    "c++",
    "c#",
    "html",
    "css",
    "react",
    "angular",
    "node.js",
    "flask",
    "django",
    "mysql",
    "sql",
    "mongodb",
    "machine learning",
    "deep learning",
    "artificial intelligence",
    "data science",
    "data analysis",
    "pandas",
    "numpy",
    "scikit-learn",
    "tensorflow",
    "pytorch",
    "nlp",
    "natural language processing",
    "git",
    "github",
    "docker",
    "aws",
    "azure",
    "power bi",
    "excel",
    "communication",
    "leadership",
    "problem solving",
    "teamwork"
]


def extract_skills(text):

    text = text.lower()

    found_skills = []

    for skill in SKILLS:

        # Escape special characters in skill names
        pattern = r"\b" + re.escape(skill) + r"\b"

        if re.search(pattern, text):

            found_skills.append(skill)

    return found_skills