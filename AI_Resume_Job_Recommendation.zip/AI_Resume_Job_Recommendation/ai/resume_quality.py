import re


def analyze_resume_quality(resume_text):

    text = resume_text.strip()
    lower_text = text.lower()

    score = 0

    strengths = []
    weaknesses = []
    suggestions = []

    # =========================================================
    # 1. RESUME LENGTH
    # =========================================================

    word_count = len(text.split())

    if word_count >= 500:

        score += 20

        strengths.append(
            "Resume contains sufficient and detailed information."
        )

    elif word_count >= 300:

        score += 15

        strengths.append(
            "Resume contains a reasonable amount of information."
        )

        suggestions.append(
            "Consider adding more details about projects, achievements or experience."
        )

    elif word_count >= 150:

        score += 8

        weaknesses.append(
            "Resume content is relatively short."
        )

        suggestions.append(
            "Add more details about your education, projects, skills and experience."
        )

    else:

        weaknesses.append(
            "Resume content is too short."
        )

        suggestions.append(
            "Add more relevant information about your education, projects, skills and experience."
        )

    # =========================================================
    # 2. CONTACT INFORMATION
    # =========================================================

    email_pattern = (
        r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"
    )

    phone_pattern = (
        r"\b(?:\+91[\s-]?)?[6-9]\d{9}\b"
    )

    has_email = re.search(email_pattern, text)
    has_phone = re.search(phone_pattern, text)

    if has_email:

        score += 10

        strengths.append(
            "Professional email address detected."
        )

    else:

        weaknesses.append(
            "Email address was not detected."
        )

        suggestions.append(
            "Add a professional email address to your resume."
        )

    if has_phone:

        score += 10

        strengths.append(
            "Phone number detected."
        )

    else:

        weaknesses.append(
            "Phone number was not detected."
        )

        suggestions.append(
            "Add a contact phone number."
        )

    # =========================================================
    # 3. EDUCATION
    # =========================================================

    education_keywords = [
        "education",
        "bachelor",
        "b.tech",
        "btech",
        "b.e",
        "be ",
        "master",
        "m.tech",
        "mtech",
        "m.e",
        "degree",
        "university",
        "college",
        "graduation",
        "graduate"
    ]

    has_education = any(
        keyword in lower_text
        for keyword in education_keywords
    )

    if has_education:

        score += 15

        strengths.append(
            "Education information detected."
        )

    else:

        weaknesses.append(
            "Education section may be missing."
        )

        suggestions.append(
            "Add your degree, college or university and graduation details."
        )

    # =========================================================
    # 4. TECHNICAL SKILLS
    # =========================================================

    skill_keywords = [
        "python",
        "java",
        "javascript",
        "html",
        "css",
        "c++",
        "c#",
        "sql",
        "mysql",
        "mongodb",
        "flask",
        "django",
        "react",
        "angular",
        "node.js",
        "machine learning",
        "deep learning",
        "artificial intelligence",
        "data science",
        "data analysis",
        "pandas",
        "numpy",
        "scikit-learn",
        "tensorflow",
        "pytorch",
        "nlp",
        "git",
        "github",
        "docker",
        "aws",
        "azure",
        "excel",
        "power bi"
    ]

    detected_skills = []

    for skill in skill_keywords:

        if skill in lower_text:

            detected_skills.append(skill)

    if len(detected_skills) >= 7:

        score += 20

        strengths.append(
            f"{len(detected_skills)} relevant technical skills detected."
        )

    elif len(detected_skills) >= 4:

        score += 15

        strengths.append(
            f"{len(detected_skills)} technical skills detected."
        )

    elif len(detected_skills) >= 2:

        score += 8

        strengths.append(
            f"{len(detected_skills)} technical skills detected."
        )

        suggestions.append(
            "Consider adding more technical skills relevant to your target job."
        )

    else:

        weaknesses.append(
            "Very few technical skills were detected."
        )

        suggestions.append(
            "Add technical skills relevant to your target job."
        )

    # =========================================================
    # 5. PROJECTS
    # =========================================================

    project_keywords = [
        "project",
        "projects",
        "developed",
        "implemented",
        "built",
        "application",
        "system",
        "prototype"
    ]

    has_projects = any(
        keyword in lower_text
        for keyword in project_keywords
    )

    if has_projects:

        score += 10

        strengths.append(
            "Project or practical experience detected."
        )

    else:

        weaknesses.append(
            "Project experience was not detected."
        )

        suggestions.append(
            "Add academic or personal projects that demonstrate your technical skills."
        )

    # =========================================================
    # 6. EXPERIENCE
    # =========================================================

    experience_keywords = [
        "experience",
        "internship",
        "intern",
        "work experience",
        "employment",
        "worked",
        "professional experience"
    ]

    has_experience = any(
        keyword in lower_text
        for keyword in experience_keywords
    )

    if has_experience:

        score += 10

        strengths.append(
            "Work or internship experience detected."
        )

    else:

        suggestions.append(
            "If applicable, include internships, training or work experience."
        )

    # =========================================================
    # 7. ACHIEVEMENTS / CERTIFICATIONS
    # =========================================================

    achievement_keywords = [
        "achievement",
        "achievements",
        "certification",
        "certifications",
        "certificate",
        "certified",
        "award",
        "awards",
        "hackathon",
        "competition"
    ]

    has_achievements = any(
        keyword in lower_text
        for keyword in achievement_keywords
    )

    if has_achievements:

        score += 5

        strengths.append(
            "Achievements or certifications detected."
        )

    else:

        suggestions.append(
            "Consider adding relevant certifications, awards or achievements."
        )

    # =========================================================
    # 8. CAREER SUMMARY / OBJECTIVE
    # =========================================================

    summary_keywords = [
        "summary",
        "professional summary",
        "career objective",
        "objective",
        "profile"
    ]

    has_summary = any(
        keyword in lower_text
        for keyword in summary_keywords
    )

    if has_summary:

        score += 5

        strengths.append(
            "Professional summary or career objective detected."
        )

    else:

        suggestions.append(
            "Consider adding a short professional summary or career objective."
        )

    # =========================================================
    # 9. FINAL SCORE
    # =========================================================

    score = min(score, 100)

    # =========================================================
    # 10. QUALITY LEVEL
    # =========================================================

    if score >= 85:

        quality = "Excellent"

    elif score >= 70:

        quality = "Good"

    elif score >= 50:

        quality = "Needs Improvement"

    else:

        quality = "Poor"

    # =========================================================
    # 11. FINAL GENERAL SUGGESTION
    # =========================================================

    if score >= 85:

        suggestions.append(
            "Your resume has a strong overall structure. Continue tailoring it to each target job."
        )

    elif score >= 70:

        suggestions.append(
            "Your resume is in good shape, but tailoring skills and achievements to the target job can improve it further."
        )

    elif score >= 50:

        suggestions.append(
            "Improve the missing sections and add more job-relevant skills, projects and achievements."
        )

    else:

        suggestions.append(
            "Consider significantly improving the resume structure, content and job-relevant information."
        )

    # =========================================================
    # 12. RETURN RESULT
    # =========================================================

    return {
        "score": score,
        "quality": quality,
        "word_count": word_count,
        "detected_skills": detected_skills,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "suggestions": suggestions
    }