# MySQL Database Configuration

MYSQL_HOST = "localhost"
MYSQL_USER = "root"
MYSQL_PASSWORD = "p@8169"
MYSQL_DB = "ai_resume_system"