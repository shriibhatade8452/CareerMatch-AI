from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session
)

import mysql.connector
import os

from werkzeug.utils import secure_filename

from config import (
    MYSQL_HOST,
    MYSQL_USER,
    MYSQL_PASSWORD,
    MYSQL_DB
)

from ai.resume_parser import extract_resume_text
from ai.skill_extractor import extract_skills
from ai.job_matcher import calculate_job_match
from ai.resume_quality import analyze_resume_quality


app = Flask(__name__)

app.secret_key = "careermatch-ai-secret-key"


# =========================================================
# FILE SETTINGS
# =========================================================

UPLOAD_FOLDER = "static/uploads"

ALLOWED_EXTENSIONS = {
    "pdf",
    "docx"
}

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(
    UPLOAD_FOLDER,
    exist_ok=True
)


# =========================================================
# DATABASE CONNECTION
# =========================================================

def get_db_connection():

    connection = mysql.connector.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB
    )

    return connection


# =========================================================
# CHECK FILE TYPE
# =========================================================

def allowed_file(filename):

    return (
        "." in filename
        and
        filename.rsplit(".", 1)[1].lower()
        in ALLOWED_EXTENSIONS
    )


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():

    return render_template(
        "index.html"
    )


# =========================================================
# REGISTER
# =========================================================

@app.route(
    "/register",
    methods=["GET", "POST"]
)
def register():

    if request.method == "POST":

        name = request.form["name"]

        email = request.form["email"]

        password = request.form["password"]

        connection = None
        cursor = None

        try:

            connection = get_db_connection()

            cursor = connection.cursor()

            query = """
                INSERT INTO users
                (name, email, password)
                VALUES (%s, %s, %s)
            """

            values = (
                name,
                email,
                password
            )

            cursor.execute(
                query,
                values
            )

            connection.commit()

            return redirect(
                url_for("login")
            )

        except mysql.connector.Error as error:

            return render_template(
                "register.html",
                error=f"Registration failed: {error}"
            )

        finally:

            if cursor:
                cursor.close()

            if connection:
                connection.close()

    return render_template(
        "register.html"
    )


# =========================================================
# LOGIN
# =========================================================

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        email = request.form["email"]

        password = request.form["password"]

        connection = None
        cursor = None

        try:

            connection = get_db_connection()

            cursor = connection.cursor(
                dictionary=True
            )

            query = """
                SELECT *
                FROM users
                WHERE email = %s
                AND password = %s
            """

            values = (
                email,
                password
            )

            cursor.execute(
                query,
                values
            )

            user = cursor.fetchone()

            if user:

                session["user_id"] = user["id"]

                session["user_name"] = user["name"]

                session["user_email"] = user["email"]

                return redirect(
                    url_for("dashboard")
                )

            return render_template(
                "login.html",
                error="Invalid email or password."
            )

        except mysql.connector.Error as error:

            return render_template(
                "login.html",
                error=f"Login failed: {error}"
            )

        finally:

            if cursor:
                cursor.close()

            if connection:
                connection.close()

    return render_template(
        "login.html"
    )


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    return render_template(
        "dashboard.html"
    )


# =========================================================
# RESUME UPLOAD
# =========================================================

@app.route(
    "/upload-resume",
    methods=["GET", "POST"]
)
def upload_resume():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if request.method == "POST":

        if "resume" not in request.files:

            return render_template(
                "upload_resume.html",
                error="Please select a resume."
            )

        file = request.files["resume"]

        if file.filename == "":

            return render_template(
                "upload_resume.html",
                error="Please select a resume."
            )

        if not allowed_file(file.filename):

            return render_template(
                "upload_resume.html",
                error="Only PDF and DOCX files are allowed."
            )

        filename = secure_filename(
            file.filename
        )

        file_path = os.path.join(
            app.config["UPLOAD_FOLDER"],
            filename
        )

        file.save(
            file_path
        )

        try:

            resume_text = extract_resume_text(
                file_path
            )

        except Exception as error:

            return render_template(
                "upload_resume.html",
                error=f"Could not read resume: {error}"
            )

        skills = extract_skills(
            resume_text
        )

        connection = None
        cursor = None

        try:

            connection = get_db_connection()

            cursor = connection.cursor()

            query = """
                INSERT INTO resumes
                (
                    user_id,
                    filename,
                    resume_text
                )
                VALUES
                (
                    %s,
                    %s,
                    %s
                )
            """

            values = (
                session["user_id"],
                filename,
                resume_text
            )

            cursor.execute(
                query,
                values
            )

            connection.commit()

        except mysql.connector.Error as error:

            return render_template(
                "upload_resume.html",
                error=f"Resume database error: {error}"
            )

        finally:

            if cursor:
                cursor.close()

            if connection:
                connection.close()

        return render_template(
            "upload_resume.html",
            success="Resume uploaded and analyzed successfully!",
            extracted_text=resume_text,
            skills=skills
        )

    return render_template(
        "upload_resume.html"
    )


# =========================================================
# JOBS
# =========================================================

@app.route("/jobs")
def jobs():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        query = """
            SELECT *
            FROM jobs
            ORDER BY created_at DESC
        """

        cursor.execute(
            query
        )

        jobs_list = cursor.fetchall()

        return render_template(
            "jobs.html",
            jobs=jobs_list
        )

    except mysql.connector.Error as error:

        return render_template(
            "jobs.html",
            jobs=[],
            error=f"Could not load jobs: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

            # =========================================================
# SKILL GAP - SELECT TARGET JOB
# =========================================================

@app.route("/skill-gap-select")
def skill_gap_select():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        query = """
            SELECT *
            FROM jobs
            ORDER BY created_at DESC
        """

        cursor.execute(query)

        jobs_list = cursor.fetchall()

        return render_template(
            "job_selection.html",
            jobs=jobs_list,
            mode="skill_gap"
        )

    except mysql.connector.Error as error:

        return render_template(
            "job_selection.html",
            jobs=[],
            mode="skill_gap",
            error=f"Could not load jobs: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# COURSES - SELECT TARGET JOB
# =========================================================

@app.route("/courses-select")
def courses_select():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        query = """
            SELECT *
            FROM jobs
            ORDER BY created_at DESC
        """

        cursor.execute(query)

        jobs_list = cursor.fetchall()

        return render_template(
            "job_selection.html",
            jobs=jobs_list,
            mode="courses"
        )

    except mysql.connector.Error as error:

        return render_template(
            "job_selection.html",
            jobs=[],
            mode="courses",
            error=f"Could not load jobs: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# JOB RECOMMENDATIONS
# =========================================================

@app.route("/job-recommendations")
def job_recommendations():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # Get latest resume
        resume_query = """
            SELECT *
            FROM resumes
            WHERE user_id = %s
            ORDER BY uploaded_at DESC
            LIMIT 1
        """

        cursor.execute(
            resume_query,
            (session["user_id"],)
        )

        resume = cursor.fetchone()

        if not resume:

            return render_template(
                "job_recommendations.html",
                error="Please upload a resume before viewing job recommendations."
            )

        # Get jobs
        jobs_query = """
            SELECT *
            FROM jobs
            ORDER BY created_at DESC
        """

        cursor.execute(
            jobs_query
        )

        jobs_list = cursor.fetchall()

        recommended_jobs = []

        # Calculate AI match
        for job in jobs_list:

            result = calculate_job_match(
                resume["resume_text"],
                job["required_skills"]
            )

            job["match_score"] = result["match_score"]

            job["matched_skills"] = (
                result["matched_skills"]
            )

            job["missing_skills"] = (
                result["missing_skills"]
            )

            if result["match_score"] > 0:

                recommended_jobs.append(
                    job
                )

        # Sort by highest match
        recommended_jobs.sort(
            key=lambda job: job["match_score"],
            reverse=True
        )

        # Remove old recommendations
        delete_query = """
            DELETE FROM recommendations
            WHERE user_id = %s
        """

        cursor.execute(
            delete_query,
            (session["user_id"],)
        )

        # Save new recommendations
        insert_query = """
            INSERT INTO recommendations
            (
                user_id,
                job_id,
                match_score,
                matched_skills,
                missing_skills
            )
            VALUES
            (
                %s,
                %s,
                %s,
                %s,
                %s
            )
        """

        for job in recommended_jobs:

            matched_skills = ", ".join(
                job["matched_skills"]
            )

            missing_skills = ", ".join(
                job["missing_skills"]
            )

            cursor.execute(
                insert_query,
                (
                    session["user_id"],
                    job["id"],
                    job["match_score"],
                    matched_skills,
                    missing_skills
                )
            )

        connection.commit()

        return render_template(
            "job_recommendations.html",
            recommendations=recommended_jobs
        )

    except mysql.connector.Error as error:

        if connection:
            connection.rollback()

        return render_template(
            "job_recommendations.html",
            error=f"Database error: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# JOB MATCH
# =========================================================

@app.route("/job-match/<int:job_id>")
def job_match(job_id):

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # Get resume
        resume_query = """
            SELECT *
            FROM resumes
            WHERE user_id = %s
            ORDER BY uploaded_at DESC
            LIMIT 1
        """

        cursor.execute(
            resume_query,
            (session["user_id"],)
        )

        resume = cursor.fetchone()

        if not resume:

            return render_template(
                "job_match.html",
                error="Please upload a resume before checking job matches."
            )

        # Get job
        job_query = """
            SELECT *
            FROM jobs
            WHERE id = %s
        """

        cursor.execute(
            job_query,
            (job_id,)
        )

        job = cursor.fetchone()

        if not job:

            return render_template(
                "job_match.html",
                error="The selected job could not be found."
            )

        # Calculate match
        result = calculate_job_match(
            resume["resume_text"],
            job["required_skills"]
        )

        matched_skills_text = ", ".join(
            result["matched_skills"]
        )

        missing_skills_text = ", ".join(
            result["missing_skills"]
        )

        # Save recommendation
        recommendation_query = """
            INSERT INTO recommendations
            (
                user_id,
                job_id,
                match_score,
                matched_skills,
                missing_skills
            )
            VALUES
            (
                %s,
                %s,
                %s,
                %s,
                %s
            )
        """

        recommendation_values = (
            session["user_id"],
            job_id,
            result["match_score"],
            matched_skills_text,
            missing_skills_text
        )

        cursor.execute(
            recommendation_query,
            recommendation_values
        )

        connection.commit()

        return render_template(
            "job_match.html",
            job=job,
            result=result
        )

    except mysql.connector.Error as error:

        if connection:
            connection.rollback()

        return render_template(
            "job_match.html",
            error=f"Database error: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# SKILL GAP ANALYSIS
# =========================================================

@app.route("/skill-gap/<int:job_id>")
def skill_gap(job_id):

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # =====================================================
        # GET LATEST RESUME
        # =====================================================

        resume_query = """
            SELECT *
            FROM resumes
            WHERE user_id = %s
            ORDER BY uploaded_at DESC
            LIMIT 1
        """

        cursor.execute(
            resume_query,
            (session["user_id"],)
        )

        resume = cursor.fetchone()

        if not resume:

            return render_template(
                "skill_gap.html",
                error="Please upload a resume before using Skill Gap Analysis."
            )

        # =====================================================
        # GET SELECTED JOB
        # =====================================================

        job_query = """
            SELECT *
            FROM jobs
            WHERE id = %s
        """

        cursor.execute(
            job_query,
            (job_id,)
        )

        job = cursor.fetchone()

        if not job:

            return render_template(
                "skill_gap.html",
                error="The selected job could not be found."
            )

        # =====================================================
        # CALCULATE SKILL GAP
        # =====================================================

        result = calculate_job_match(
            resume["resume_text"],
            job["required_skills"]
        )

        # =====================================================
        # SHOW SKILL GAP
        # =====================================================

        return render_template(
            "skill_gap.html",
            job=job,
            result=result
        )

    except mysql.connector.Error as error:

        return render_template(
            "skill_gap.html",
            error=f"Database error: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# COURSE RECOMMENDATIONS
# =========================================================

@app.route("/courses/<int:job_id>")
def courses(job_id):

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    connection = None
    cursor = None

    try:

        connection = get_db_connection()

        cursor = connection.cursor(
            dictionary=True
        )

        # Get job
        job_query = """
            SELECT *
            FROM jobs
            WHERE id = %s
        """

        cursor.execute(
            job_query,
            (job_id,)
        )

        job = cursor.fetchone()

        if not job:

            return render_template(
                "courses.html",
                error="The selected job could not be found."
            )

        # Get latest resume
        resume_query = """
            SELECT *
            FROM resumes
            WHERE user_id = %s
            ORDER BY uploaded_at DESC
            LIMIT 1
        """

        cursor.execute(
            resume_query,
            (session["user_id"],)
        )

        resume = cursor.fetchone()

        if not resume:

            return render_template(
                "courses.html",
                error="Please upload a resume first."
            )

        # Calculate skill gap
        result = calculate_job_match(
            resume["resume_text"],
            job["required_skills"]
        )

        missing_skills = result["missing_skills"]

        courses_list = []

        # Find courses for every missing skill
        for skill in missing_skills:

            course_query = """
                SELECT *
                FROM courses
                WHERE LOWER(skill) = LOWER(%s)
            """

            cursor.execute(
                course_query,
                (skill,)
            )

            skill_courses = cursor.fetchall()

            courses_list.extend(
                skill_courses
            )

        return render_template(
            "courses.html",
            job=job,
            result=result,
            courses=courses_list
        )

    except mysql.connector.Error as error:

        return render_template(
            "courses.html",
            error=f"Database error: {error}"
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# =========================================================
# RESUME QUALITY
# =========================================================

@app.route("/resume-quality")
def resume_quality():

    if "user_id" not in session:
        return redirect(url_for("login"))

    connection = None
    cursor = None

    try:

        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        query = """
            SELECT *
            FROM resumes
            WHERE user_id = %s
            ORDER BY uploaded_at DESC
            LIMIT 1
        """

        cursor.execute(
            query,
            (session["user_id"],)
        )

        resume = cursor.fetchone()

        if not resume:

            return render_template(
                "resume_quality.html",
                result={
                    "score": 0,
                    "quality": "No Resume",
                    "word_count": 0,
                    "detected_skills": [],
                    "strengths": [],
                    "weaknesses": [
                        "No resume has been uploaded yet."
                    ],
                    "suggestions": [
                        "Upload a PDF or DOCX resume first."
                    ]
                }
            )

        resume_text = resume.get("resume_text") or ""

        result = analyze_resume_quality(resume_text)

        return render_template(
            "resume_quality.html",
            result=result
        )

    except mysql.connector.Error as error:

        return render_template(
            "resume_quality.html",
            result={
                "score": 0,
                "quality": "Error",
                "word_count": 0,
                "detected_skills": [],
                "strengths": [],
                "weaknesses": [
                    "Unable to load your resume from the database."
                ],
                "suggestions": [
                    f"Database error: {error}"
                ]
            }
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =========================================================
# CAREER DEVELOPMENT
# =========================================================

@app.route("/career-development")
def career_development():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    return render_template(
        "career_development.html"
    )


# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("home")
    )


# =========================================================
# START APPLICATION
# =========================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )